module.exports = {
    name: "afk",
    type: "messageCreate",
    code: `
    $sendMessage[$channelID;$title[AFK set] $description[I have marked you as AFK in server, with reason : $replace[$replace[$replace[?=÷$message%#>;?=÷%#>;No reason set];?=÷; ];%#>; ]] $footer[$username;$userAvatar[$authorID]] $color[#ca1bbf]]$setVar[afkname;$authorID;$nickname[$guildID;$authorID]] $function[$memberSetNickname[982931539941818408;$authorID;{afk}$nickname]]$setVar[afkon;$authorID;true]
$setVar[afktimestamp;$authorID;$divide[$getTimestamp;1000]]
$setVar[afkreason;$authorID;$replace[$replace[$replace[?=÷$message%#>;?=÷%#>;No reason set];?=÷; ];%#>; ]]
    `,
    unprefixed: false

}
