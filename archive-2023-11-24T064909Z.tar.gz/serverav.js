module.exports = {
    name: "server-avatar",
    aliases: ["sav", "s-avatar"],
    type: "messageCreate",
    code:`$sendMessage[$channelID;$title[> $userDisplayName[$mentioned[0;true]]'s' Avatar] $image[$memberAvatar[$guildID;$mentioned[0;true]]
] $footer[🖼 Avatar Fetched | $timestamp] $color[#ca1bbf] $author[🖼 Avatar Tool]]`
}