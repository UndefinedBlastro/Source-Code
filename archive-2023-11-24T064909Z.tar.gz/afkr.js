module.exports = {
    name: "",
    type: "messageCreate",
    code:`$if[$getVar[afkon;$authorID;false]==true;
    Welcome Back $username[$authorID]! I have turned off your afk because you sent a message.
    Afk since: <t:$round[$getVar[afktimestamp;$authorID;no timestamp]]:R>
    
    $if[$getVar[pingswhileafk;$authorID;0]>=1;
    $description[You got $getVar[pingswhileafk;$authorID;0] ping(s) since you went afk!
    
    ### Pingers and Messages:
    $getVar[messageswithping;$authorID; ]]$color[#ca1bbf]
    ]
$wait[100]
$setVar[messageswithping;$authorID; ]
$setVar[pingswhileafk;$authorID;0]
$setVar[afktimestamp;$authorID;no timestamp]
$setVar[afkon;$authorID;false]
$function[$memberSetNickname[$guildID;$authorID;$getVar[afkname;$authorID]]]
    ]`,
    unprefixed: false

}
