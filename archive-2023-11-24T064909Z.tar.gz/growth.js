module.exports = {
    name: "grow",
    type: "messageCreate",
    code:`
    ㅤ$sendMessage[$channelID;$title[Server Members and Boost Count]
        $addField[Server Members;$guildMemberCount;true]
$addField[Boost Count;$guildBoostCount;true]$color[#ca1bbf]]`,
    unprefixed: true

}
