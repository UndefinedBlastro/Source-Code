module.exports = {
    name: "say",
    aliases: ["ev", "make"],
    type: "messageCreate",
    code: `
    $onlyIf[$authorID==963802964185735178;You need Admin perm] $sendMessage[$channelID;$message]
    `,
    unprefixed: false
}
