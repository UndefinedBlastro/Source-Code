module.exports = {
    name: "",
    type: "messageCreate",
    code:`$if[$mentioned[0]!=;
$if[$mentioned[0]==$authorID;;
    $if[$getVar[afkon;$mentioned[0];false]==true;
    $userDisplayName[$mentioned[0]] is currently afk : $getVar[afkreason;$mentioned[0];No reason set] - <t:$round[$getVar[afktimestamp;$mentioned[0]]]:R> .
    
   $function[$setVar[pingswhileafk;$mentioned[0];$math[$getVar[pingswhileafk;$mentioned[0];0]+1]]
$setVar[messageswithping;$mentioned[0];$getVar[messageswithping;$mentioned[0]; ]

<@$authorID>:
$message
[Message Link\\](https://discord.com/channels/$guildID/$channelID/$messageID)
<t:$round[$divide[$getTimestamp;1000]]:R>
]]
]]]`,
    unprefixed: true

}
