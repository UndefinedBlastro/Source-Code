module.exports = {
    name: "req",
    type: "messageCreate",
    code: `$sendMessage[1153979847035596820;$title[<a:exclamation_mark:1160909279788810322> New Request <a:exclamation_mark:1160909279788810322>] $description[$userDisplayName has requested for $message] $footer[Thank You!!] $color[#ca1bbf]<@&1088051165217968168> New Request by $userDisplayName <a:exclamation_mark:1160909279788810322> ]
    `
 }
